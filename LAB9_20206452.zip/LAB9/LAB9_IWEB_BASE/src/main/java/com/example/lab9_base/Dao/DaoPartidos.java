package com.example.lab9_base.Dao;

import com.example.lab9_base.Bean.Partido;
import com.example.lab9_base.Bean.Seleccion;
import com.example.lab9_base.Bean.Arbitro;

import java.sql.*;
import java.util.ArrayList;

public class DaoPartidos {
    public ArrayList<Partido> listaDePartidos() {

        ArrayList<Partido> partidos = new ArrayList<>();
        String query = "SELECT idPartido, seleccionLocal, seleccionVisitante, arbitro, fecha, numeroJornada FROM partido";

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/lab9", "root", "root");
             PreparedStatement ps = conn.prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Partido partido = new Partido();

                partido.setIdPartido(rs.getInt("idPartido"));
                partido.setFecha(rs.getString("fecha"));
                partido.setNumeroJornada(rs.getInt("numeroJornada"));

                Seleccion seleccionLocal = new Seleccion();
                seleccionLocal.setIdSeleccion(rs.getInt("seleccionLocalId"));
                seleccionLocal.setNombre(rs.getString("seleccionLocalNombre"));
                partido.setSeleccionLocal(seleccionLocal);

                Seleccion seleccionVisitante = new Seleccion();
                seleccionVisitante.setIdSeleccion(rs.getInt("seleccionVisitanteId"));
                seleccionVisitante.setNombre(rs.getString("seleccionVisitanteNombre"));
                partido.setSeleccionVisitante(seleccionVisitante);

                Arbitro arbitro = new Arbitro();
                arbitro.setIdArbitro(rs.getInt("idArbitro"));
                arbitro.setNombre(rs.getString("arbitroNombre"));
                partido.setArbitro(arbitro);

                partidos.add(partido);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return partidos;

    }

    public void crearPartido(Partido partido) {

        String query = "INSERT INTO partido (seleccionLocal, seleccionVisitante, arbitro, fecha, numeroJornada) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/lab9", "root", "root");
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setInt(1, partido.getSeleccionLocal().getIdSeleccion());
            ps.setInt(2, partido.getSeleccionVisitante().getIdSeleccion());
            ps.setInt(3, partido.getArbitro().getIdArbitro());
            ps.setString(4, partido.getFecha());
            ps.setInt(5, partido.getNumeroJornada());

            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
