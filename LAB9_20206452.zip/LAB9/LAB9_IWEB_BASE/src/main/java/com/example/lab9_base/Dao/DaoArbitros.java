package com.example.lab9_base.Dao;

import com.example.lab9_base.Bean.Arbitro;

import java.util.ArrayList;
import java.sql.*;

public class DaoArbitros {
    public ArrayList<Arbitro> listarArbitros() {
        ArrayList<Arbitro> arbitros = new ArrayList<>();

        String query = "SELECT idArbitro, nombre, pais FROM arbitro";
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/lab9", "root", "root");
             PreparedStatement ps = conn.prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Arbitro arbitro = new Arbitro();
                arbitro.setIdArbitro(rs.getInt("idArbitro"));
                arbitro.setNombre(rs.getString("nombre"));
                arbitro.setPais(rs.getString("pais"));
                arbitros.add(arbitro);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return arbitros;
    }

    public void crearArbitro(Arbitro arbitro) {
        String query = "INSERT INTO arbitro (nombre, pais) VALUES (?, ?)";
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/lab9", "root", "root");
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setString(1, arbitro.getNombre());
            ps.setString(2, arbitro.getPais());
            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public ArrayList<Arbitro> busquedaPais(String pais) {

        ArrayList<Arbitro> arbitros = new ArrayList<>();
        String query = "SELECT idArbitro, nombre, pais FROM arbitro WHERE pais = ?";
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/lab9", "root", "root");
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setString(1, pais);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Arbitro arbitro = new Arbitro();
                    arbitro.setIdArbitro(rs.getInt("idArbitro"));
                    arbitro.setNombre(rs.getString("nombre"));
                    arbitro.setPais(rs.getString("pais"));
                    arbitros.add(arbitro);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return arbitros;
    }

    public ArrayList<Arbitro> busquedaNombre(String nombre) {

        ArrayList<Arbitro> arbitros = new ArrayList<>();
        String query = "SELECT idArbitro, nombre, pais FROM arbitro WHERE nombre LIKE ?";
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/lab9", "root", "root");
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setString(1, "%" + nombre + "%");
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Arbitro arbitro = new Arbitro();
                    arbitro.setIdArbitro(rs.getInt("idArbitro"));
                    arbitro.setNombre(rs.getString("nombre"));
                    arbitro.setPais(rs.getString("pais"));
                    arbitros.add(arbitro);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return arbitros;
    }

    public Arbitro buscarArbitro(int id) {

        Arbitro arbitro = null;
        String query = "SELECT idArbitro, nombre, pais FROM arbitro WHERE idArbitro = ?";
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/lab9", "root", "root");
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    arbitro = new Arbitro();
                    arbitro.setIdArbitro(rs.getInt("idArbitro"));
                    arbitro.setNombre(rs.getString("nombre"));
                    arbitro.setPais(rs.getString("pais"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return arbitro;
    }

    public void borrarArbitro(int id) {
        String query = "DELETE FROM arbitro WHERE idArbitro = ?";
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/lab9", "root", "root");
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setInt(1, id);
            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }

    }
}
